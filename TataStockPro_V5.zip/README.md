Tata Stock Pro - PWA
5 pages: index, dashboard, product, sell, history
Install: upload files to GitHub repo root, enable Pages (main branch, root). Open Pages URL in Chrome and "Add to Home screen".
